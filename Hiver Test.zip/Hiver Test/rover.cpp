#include <bits/stdc++.h>

using namespace std;

void displayCommands(){
	cout<<"L - turn left"<<endl;
	cout<<"R - turn right"<<endl;
	cout<<"M - move forward"<<endl;
	cout<<"? - print this message"<<endl;
	cout<<"Q - quit"<<endl;
}

int main(){
	map<char,pair<int,int> >move;
	vector <char> direction;
	map<char,string>message;

	direction.push_back('N');
	direction.push_back('E');
	direction.push_back('S');
	direction.push_back('W');

	move['N']=make_pair(0,1);
	move['E']=make_pair(1,0);
	move['S']=make_pair(0,-1);
	move['W']=make_pair(-1,0);

	message['N']="North";
	message['E']="East";
	message['S']="South";
	message['W']="West";

	cout<<"Hello! Robot coming online."<<endl<<"Command the robot with: "<<endl;
	char cmd;
	pair<int,int>position = make_pair(0,0);
	int current_direction = 0; 

	while(1){

		cin>>cmd;

		if(cmd == 'Q'){
			cout<<"shutting down..."<<endl;
			break;
		}
		else if(cmd == '?'){
			displayCommands();
			continue;
		}
		else if(cmd =='M'){
			position.first+=move[direction[current_direction]].first;
			position.second+=move[direction[current_direction]].second;
		}
		else if(cmd == 'L'){
			current_direction = (direction.size()+current_direction-1)%direction.size();
		}
		else if(cmd == 'R'){
			current_direction = (direction.size()+current_direction+1)%direction.size();	
		}
		cout<<"Robot at ("<<position.first<<", "<<position.second<<") facing "<<message[direction[current_direction]]<<endl;
	}
}
#include <bits/stdc++.h>
#include <string>


using namespace std;

map<string,vector<string> >anagrams;

string getPattern(string input){
	vector<int>v(255,0);

	for(int i=0;i<input.length();i++){
		v[input[i]]++;
	}

	string pattern = "";
	for(int i=0;i<255;i++){
		pattern = pattern+"_"+to_string(v[i]);
	}
	return pattern;
}

void insertString(string input){
	string pattern = getPattern(input);
	anagrams[pattern].push_back(input);
}

int main(){
	
	insertString("asd");
	insertString("das");
	insertString("asdd");
	insertString("fre");

	string ip = "sad";
	string pattern = getPattern(ip);

	if(anagrams.find(pattern)!=anagrams.end()){
		for(int i=0;i<anagrams[pattern].size();i++){
			cout<<anagrams[pattern][i]<<endl;
		}
	}

}